package part.pkg1;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;

public class LoginFrame extends JFrame {
    private final HashMap<String, User> users;
    private JTextField loginUsernameField;
    private JPasswordField loginPasswordField;
    private JButton loginButton;
    private JButton loginRegisterButton;
    private final Color SHOCKING_GREEN = new Color(57, 255, 20);

    public LoginFrame(HashMap<String, User> users) {
        this.users = users;
        initializeUI();
    }

    private void initializeUI() {
        setTitle("Login");
        setSize(420, 380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(SHOCKING_GREEN);
        panel.setLayout(null);

        // Title
        JLabel titleLabel = new JLabel("Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setBounds(170, 30, 100, 35);
        panel.add(titleLabel);

        // Username
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.BLACK);
        usernameLabel.setBounds(50, 100, 100, 25);
        panel.add(usernameLabel);

        loginUsernameField = new JTextField();
        loginUsernameField.setBounds(160, 100, 180, 25);
        panel.add(loginUsernameField);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.BLACK);
        passwordLabel.setBounds(50, 140, 100, 25);
        panel.add(passwordLabel);

        loginPasswordField = new JPasswordField();
        loginPasswordField.setBounds(160, 140, 180, 25);
        panel.add(loginPasswordField);

        // Buttons
        loginButton = new JButton("Login");
        loginButton.setBounds(160, 190, 100, 30);
        loginButton.setBackground(Color.BLACK);
        loginButton.setForeground(SHOCKING_GREEN);
        loginButton.setFocusPainted(false);
        panel.add(loginButton);

        loginRegisterButton = new JButton("New User? Register");
        loginRegisterButton.setBounds(140, 235, 140, 30);
        loginRegisterButton.setBackground(Color.BLACK);
        loginRegisterButton.setForeground(SHOCKING_GREEN);
        loginRegisterButton.setFocusPainted(false);
        panel.add(loginRegisterButton);

        // Event listeners
        loginButton.addActionListener(e -> handleLogin());
        loginRegisterButton.addActionListener(e -> navigateToRegistration());

        add(panel);
    }

    private void handleLogin() {
        String username = loginUsernameField.getText().trim();
        String password = new String(loginPasswordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter both username and password.", "Missing Fields");
            return;
        }

        User user = users.get(username);
        if (user == null) {
            showError("Username not found. Please register first.", "User Not Found");
            return;
        }

        if (!user.getPassword().equals(password)) {
            showError("Incorrect password. Please try again.", "Login Failed");
            return;
        }

        showSuccess("Login successful! Welcome, " + username + ".");
        clearLoginFields();
    }

    public boolean loginUser(String username, String password) {
        if (username == null || password == null || username.isEmpty() || password.isEmpty()) {
            return false;
        }

        User user = users.get(username);
        return user != null && user.getPassword().equals(password);
    }

    private void navigateToRegistration() {
        dispose();
        new RegistrationFrame(users).setVisible(true);
    }

    private void showError(String message, String title) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearLoginFields() {
        loginUsernameField.setText("");
        loginPasswordField.setText("");
    }
}