package part.pkg1;

import org.junit.Test;
import static org.junit.Assert.*;

public class SimpleTest {
    
    @Test
    public void testBasicAddition() {
        assertEquals("1 + 1 should equal 2", 2, 1 + 1);
    }
    
    @Test
    public void testStringEquality() {
        assertEquals("Hello should equal Hello", "Hello", "Hello");
    }
}
